package com.example.personal_information_manager

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
